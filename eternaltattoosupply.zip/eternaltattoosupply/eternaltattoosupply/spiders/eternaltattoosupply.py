from scrapy import Request
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor

from ..items import EternaltattoosupplyItem

#from datetime import date


class EternalTattooSupplySpider(CrawlSpider):

    name = "eternaltattoosupply"

    img_link = "https:"

    start_urls = [
                "https://www.eternaltattoosupply.com/"
    ]

    rules = (
        Rule(LinkExtractor(restrict_css=([".site-nav--has-dropdown ul"]))),
        Rule(LinkExtractor(restrict_css=(".grid__item.wide--one-fifth.large--one-quarter.medium-down--one-half a")),callback="eternaltattoosupply"),  
    )


    def eternaltattoosupply(self, response):

        products = EternaltattoosupplyItem()

        products["title"] = response.css(".product-single h1::text").extract_first()
        products["price"] = response.css("#ProductPrice::text").extract_first().strip("\n ")

        products["description"] = response.css(".product-description.rte span::text").extract()

        if not products["description"]:
            products["description"] = response.css(".product-description.rte p::text").extract()

        if not products["description"]:
            products["description"] = response.css(".product-description.rte div::text").extract()

        if not products["description"]:
            products["description"] = response.css(".product-description.rte::text").extract()



        products["images"] = response.css("li.grid__item img::attr(src)").extract()

        for img in range(len(products["images"])):
            temp = self.img_link
            products["images"][img] = temp + products["images"][img]

        if not products["images"]:
            temp = self.img_link
            products["images"] = response.css(".product-single__photos img::attr(src)").extract_first()
            products["images"] = temp + products["images"]

        products["category"] = response.css(".breadcrumb a:nth-child(3)::text").extract_first()

        products["url"] = response.url

        products["option"] = response.css(".product-single__variants option::text").extract()

        if "Default" in products["option"]:
            products["option"] = None

        for option in range(len(products["option"])):
            products["option"][option] = products["option"][option].strip("\n")
            products["option"][option] = products["option"][option].strip(" ")
            products["option"][option] = products["option"][option].replace(" - Sold Out","")

        yield products
 